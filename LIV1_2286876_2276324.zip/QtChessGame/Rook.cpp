// Rook.cpp: Represents the Rook piece, handling its straight-line movement.
#include "Rook.h"

Rook::Rook() {
    // Constructor code here
}

// Methods to check for valid Rook moves.

#pragma once
// PlayingWindow.h: Header for the game UI during play.
#ifndef PLAYINGWINDOW_H
#define PLAYINGWINDOW_H

#include <QWidget>

class PlayingWindow : public QWidget {
    Q_OBJECT
public:
    PlayingWindow();
    // UI interaction methods
};

#endif // PLAYINGWINDOW_H

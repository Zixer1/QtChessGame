// Pawn.cpp: Implements the Pawn piece, including its unique first-move, capturing, and promotion logic.
#include "Pawn.h"

Pawn::Pawn() {
    // Constructor code here
}

// Methods for pawn movement and promotion.

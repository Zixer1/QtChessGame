#pragma once
// Knight.h: Header for the Knight piece, detailing its unique movement.
#ifndef KNIGHT_H
#define KNIGHT_H

#include "Piece.h"

class Knight : public Piece {
public:
    Knight();
    // Implement methods for Knight's movement validation
};

#endif // KNIGHT_H

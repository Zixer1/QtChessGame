// Knight.cpp: Defines the Knight piece and its L-shaped movement on the chessboard.
#include "Knight.h"

Knight::Knight() {
    // Constructor code here
}

// Implement methods for validating the Knight's moves.

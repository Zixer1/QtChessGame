// PlayingWindow.cpp: Manages the in-game user interface, including board rendering and user interactions.
#include "PlayingWindow.h"

PlayingWindow::PlayingWindow() {
    // Constructor code here
}

// Methods related to the UI and game interaction, such as responding to user moves.

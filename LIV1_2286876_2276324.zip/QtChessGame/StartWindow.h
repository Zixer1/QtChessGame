#pragma once
// StartWindow.h: Header for the initial game setup window.
#ifndef STARTWINDOW_H
#define STARTWINDOW_H

class StartWindow {
public:
    StartWindow();
    // Setup methods for new game initialization
};

#endif // STARTWINDOW_H

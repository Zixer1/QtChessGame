// Queen.cpp: Defines the Queen piece which combines the power of Rook and Bishop.
#include "Queen.h"

Queen::Queen() {
    // Constructor code here
}

// Implementation of Queen's move validation.

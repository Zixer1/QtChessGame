// StartWindow.cpp: Represents the startup window of the game, allows for game configuration before starting.
// Would Have a Mute audio button, a Start button and an Exit button
#include "StartWindow.h"

StartWindow::StartWindow() {
    // Constructor code here
}

// Setup methods and UI controls to initiate a new game.

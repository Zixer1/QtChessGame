#pragma once
// Piece.h: Base class for all chess pieces.
#ifndef PIECE_H
#define PIECE_H

class Piece {
protected:
    // Attributes like current position, color, etc.
public:
    Piece();
    // General methods for all pieces
};

#endif // PIECE_H

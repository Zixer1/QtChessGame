// King.cpp: Contains logic for the King's movements and special moves like castling.
#include "King.h"

King::King() {
    // Constructor code here
}

// Additional methods for King's move validation.

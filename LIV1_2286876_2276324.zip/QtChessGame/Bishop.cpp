// Bishop.cpp: This file defines the behaviors unique to the Bishop chess piece, such as valid movement patterns.
#include "Bishop.h"

Bishop::Bishop() {
    // Constructor code here
}

// Other Bishop-specific methods here

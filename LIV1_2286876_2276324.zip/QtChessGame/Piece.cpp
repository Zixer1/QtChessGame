// Piece.cpp: The base class for all chess pieces, containing common attributes like position and color.
#include "Piece.h"

Piece::Piece() {
    // Constructor code here
}

// General methods applicable to all pieces, such as move validation and capture.

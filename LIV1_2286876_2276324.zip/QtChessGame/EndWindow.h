#pragma once
// EndWindow.h: Defines the end game window interface.
#ifndef ENDWINDOW_H
#define ENDWINDOW_H

class EndWindow {
public:
    EndWindow();
    // Methods for end game display
};

#endif // ENDWINDOW_H

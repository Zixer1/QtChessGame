/********************************************************************************
** Form generated from reading UI file 'QtChessGame.ui'
**
** Created by: Qt User Interface Compiler version 6.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTCHESSGAME_H
#define UI_QTCHESSGAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QtChessGameClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QtChessGameClass)
    {
        if (QtChessGameClass->objectName().isEmpty())
            QtChessGameClass->setObjectName("QtChessGameClass");
        QtChessGameClass->resize(600, 400);
        menuBar = new QMenuBar(QtChessGameClass);
        menuBar->setObjectName("menuBar");
        QtChessGameClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(QtChessGameClass);
        mainToolBar->setObjectName("mainToolBar");
        QtChessGameClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(QtChessGameClass);
        centralWidget->setObjectName("centralWidget");
        QtChessGameClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(QtChessGameClass);
        statusBar->setObjectName("statusBar");
        QtChessGameClass->setStatusBar(statusBar);

        retranslateUi(QtChessGameClass);

        QMetaObject::connectSlotsByName(QtChessGameClass);
    } // setupUi

    void retranslateUi(QMainWindow *QtChessGameClass)
    {
        QtChessGameClass->setWindowTitle(QCoreApplication::translate("QtChessGameClass", "QtChessGame", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QtChessGameClass: public Ui_QtChessGameClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTCHESSGAME_H

// EndWindow.cpp: Defines the end game window that displays the game result (win/lose/draw).
#include "EndWindow.h"

EndWindow::EndWindow() {
    // Constructor code here
}

// Methods for displaying the result and options for the player post-game.

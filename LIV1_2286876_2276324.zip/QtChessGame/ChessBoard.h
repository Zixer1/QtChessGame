#pragma once
// ChessBoard.h: Header for managing the state of the chessboard.
#ifndef CHESSBOARD_H
#define CHESSBOARD_H

#include "Piece.h"

class ChessBoard {
public:
    ChessBoard();
    // Methods for board state management
};

#endif // CHESSBOARD_H
